import { GameLaunchInfo } from 'flashpoint-launcher';
export default function NgRuffleEmbed(props: GameLaunchInfo): import("react/jsx-runtime").JSX.Element;
