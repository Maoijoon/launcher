export * from './compiled-types/components/NgRuffleEmbed';
export { default } from './compiled-types/components/NgRuffleEmbed';